<?php
    require_once dirname(dirname(__FILE__))."/config/constante.php";
    require_once dirname(dirname(__FILE__))."/config/require.php";
    open_session();
    require_once dirname(dirname(__FILE__))."/config/router.php";
?>