<?php
     //chemin absolu pour l'inclusion de nos fichiers
     define("PATH_ROOT",str_replace("public","",$_SERVER["DOCUMENT_ROOT"]));
     //chemin des actions des formulaires et des liens
     define("WEB_ROOT","http://localhost:9000/index.php");
?>