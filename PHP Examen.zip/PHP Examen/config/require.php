<?php
//require charge tous les fichers se trouvant dans core et models
    require_once(PATH_ROOT."core/session.php");
    require_once(PATH_ROOT."core/helper.php");
    require_once(PATH_ROOT."core/database.php");
    require_once(PATH_ROOT."core/validator.php");
    require_once(PATH_ROOT."models/user.model.php");
?>